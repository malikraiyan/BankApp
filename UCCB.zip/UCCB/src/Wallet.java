import java.util.ArrayList;
import java.util.List;

public class Wallet {
    private final int startingBalance;
    private List<Integer> transactions= new ArrayList<>();
    public List<Integer> getTransactions() {
        return transactions;
    }
    public Wallet(int startingBalance){
        this.startingBalance=startingBalance;
    }
    public void deposit(int amount){
        transactions.add(amount);
    }
    
    public int currentBalance(){
        int balance=startingBalance;
        for(int transaction:transactions){
            balance+=transaction;
        }
        return balance;

    }
    public boolean withdraw(int amount){

        if(amount<0){
            return false;
        }
        if(currentBalance()>=amount){
            transactions.add(-amount);
            return true;

        }
        return false;
    }

}
