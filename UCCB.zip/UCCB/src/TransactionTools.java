import java.util.ArrayList;

public class TransactionTools {
    static boolean isDuplicate(Transaction transaction1,Transaction transaction2){
        if(transaction1==null || transaction2==null){
            return false;
        }
        if(transaction1.getAmount()==transaction2.getAmount() && transaction1.getReference().equals(transaction2.getReference()) && transaction1.getType().equals(transaction2.getType())) {
            return true;
        }
        return false;

    }
    static boolean containsDuplicate(Transaction[] transactions){
        for( int i=0; i<transactions.length; i++){
            for(int j=i+1; j<transactions.length; j++) {
                if (isDuplicate(transactions[i], transactions[j])){
                    return true;
                }

            }
        }
        return false;
    }
    static int countMatchingTransactions(Transaction transaction, ArrayList<Transaction>transactionList){
        int count=0;
        for(Transaction t:transactionList){
            if(isDuplicate(transaction, t)){
                count++;
            }
        }
        return count;
    }
    static void removeDuplicates(ArrayList<Transaction>transactionList){
        for(int i=transactionList.size()-1; i>=0;i--){
            Transaction current=transactionList.get(i);
            for(int j=i+1; j<transactionList.size();j++){
                if(isDuplicate(current,transactionList.get(j))){
                    transactionList.remove(i);
                    break;
                }
            }
        }
    }





}
