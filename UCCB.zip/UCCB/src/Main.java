import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Wallet wallet = new Wallet(0);

        boolean running = true;

        while (running) {

            System.out.println("MENU");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. View Balance");
            System.out.println("4. View Transactions");
            System.out.println("5. Exit");
            System.out.println("Choose option: ");

            try {
                int choice = scanner.nextInt();

                switch (choice) {

                    case 1:
                        System.out.print("Enter deposit amount: ");
                        int deposit = scanner.nextInt();
                        wallet.deposit(deposit);
                        System.out.println("Deposit added. ");
                        break;

                    case 2:
                        System.out.print("Enter withdrawal amount: ");
                        int withdraw = scanner.nextInt();
                        boolean success = wallet.withdraw(withdraw);

                        if (success) {
                            System.out.println("Withdrawal successful.");
                        } else {
                            System.out.println("Withdrawal failed.");
                        }
                        break;

                    case 3:
                        System.out.println("Balance: " + wallet.currentBalance());
                        break;

                    case 4:
                        System.out.println("Transactions: " + wallet.getTransactions());
                        break;

                    case 5:
                        running = false;
                        System.out.println("Exiting.");
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.nextLine();
            }
        }


        scanner.close();

    }
}