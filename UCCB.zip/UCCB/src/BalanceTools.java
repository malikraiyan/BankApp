public class BalanceTools {
    static int newBalance (int balance, int deposit){
        int newTotal= balance+deposit;
        return newTotal;
    }
    static boolean hasAvailableFunds(int currentBalance, int amountOfTransaction) {
        if(currentBalance>=amountOfTransaction)
        {
            return true;
        }
        else{
            return false;
        }


    }
    static int annualBondInterest(int openingBalance,double interestRate){

        int amountOfInterest=(int)(openingBalance*interestRate);
        return amountOfInterest;
    }
    static int bondIllustration(int startingBalance, double interestRate){
        int interest=annualBondInterest(startingBalance, interestRate);
        int expectedBalance=startingBalance+interest;
        return expectedBalance;
    }
    static int bondIllustration(int openingBalance,double annualInterestRate,int years){
        int balance=openingBalance;
        for(int i=0; i<years; i++){
            balance=bondIllustration(balance,annualInterestRate);
        }
        return balance;

    }











}
