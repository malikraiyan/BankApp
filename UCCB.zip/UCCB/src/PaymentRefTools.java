import java.util.ArrayList;

public class PaymentRefTools {
    static boolean isHyphen(char hyphen){
        if(hyphen=='-'){
            return true;
        }
        else{
            return false;
        }
    }
    static boolean isFullStop(char fullStop){
        if(fullStop=='.'){
            return true;
        }
        else{
            return false;
        }
    }
    static boolean isSpace(char space){
        if(space==' '){
            return true;
        }
        else{
            return false;
        }
    }
    static boolean isValidSymbolForPaymentReference(char alphabet){

        boolean hyphen = isHyphen(alphabet);
        boolean fullstop = isFullStop(alphabet);
        boolean space = isSpace(alphabet);
        if(hyphen==true || fullstop==true || space==true){
            return true;
        }
        else{
            return false;
        }

    }
    static boolean isLowerLatinAlphabet(char alphabet){
        if (alphabet>='a' & alphabet<='z'){
            return true;

        }
        else{
            return false;
        }
    }
    static boolean isUpperLatinAlphabet(char alphabet){
        if (alphabet>='A' & alphabet<='Z'){
            return true;

        }
        else{
            return false;
        }

    }
    static boolean isLatinAlphabet(char character){
        boolean lowerLatinAlphabet=isLowerLatinAlphabet(character);
        boolean upperLatinAlphabet=isUpperLatinAlphabet(character);
        if(lowerLatinAlphabet==true || upperLatinAlphabet== true){
            return true;
        }
        else{
            return false;
        }

    }
    static boolean isValidCharacterForPaymentReference(char character){

        boolean hyphen=isHyphen(character);
        boolean fullstop=isFullStop(character);
        boolean space=isSpace(character);
        boolean LatinAlphabet=isLatinAlphabet(character);

        boolean digit=Character.isDigit(character);

        if (hyphen==true ||fullstop==true || space==true || LatinAlphabet==true ||  digit==true ){
            return true;

        }
        else{
            return false;
        }
    }
    static boolean exceedsMaximumPaymentRefLength(String refLength){
        int length=refLength.length();
        if(length>40){
            return true;
        }
        else{
            return false;
        }
    }
    static String truncate(String paymentRefrence, int maxLength){
        if(paymentRefrence.length()>maxLength){
            return paymentRefrence.substring(0,maxLength);
        }
        else{
            return paymentRefrence;
        }
    }
    static int countLongPaymentRefs(String[] paymentRefs) {
        int count = 0;

        for (String ref : paymentRefs) {
            if (ref != null && exceedsMaximumPaymentRefLength(ref)) {
                count++;
            }
        }

        return count;
    }
    static void filterLongPaymentRefs(ArrayList<String> paymentRefs){
        for(int i=paymentRefs.size()-1; i>=0; i--){
            if(exceedsMaximumPaymentRefLength(paymentRefs.get(i))){
                paymentRefs.remove(i);
            }
        }


    }












}
