public class StandardBankAccount extends BankAccountBase {
    public StandardBankAccount() {
        super();
    }

    public boolean canMakePayment(double amount) {
        return balance >= amount;
    }
}
