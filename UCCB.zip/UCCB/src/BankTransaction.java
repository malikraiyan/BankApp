import java.time.LocalDateTime;

    public class BankTransaction {

        private final double amount;
        private final String reference;
        private final LocalDateTime dateTime;

        public BankTransaction(double amount, String reference) {
            this.amount = amount;
            this.reference = reference;
            this.dateTime = LocalDateTime.now();
        }

        public double getAmount() {
            return amount;
        }

        public String getReference() {
            return reference;
        }

        public LocalDateTime getDateTime() {
            return dateTime;
        }
    }

