import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RegularSaverAccount {
    private final double normalInterestRate;
    private final double reducedInterestRate;
    private final double maxMonthlyDeposit;
    private final int maxAllowedWithdrawals;
    private List<BankTransaction> transactions;
    private final LocalDate openingDate;
    private double balance;
    private int withdrawalCount;
    public RegularSaverAccount(double normalInterestRate, double reducedInterestRate, double maxMonthlyDeposit, int maxAllowedwithDrawals){
        this.normalInterestRate=normalInterestRate;
        this.reducedInterestRate=reducedInterestRate;
        this.maxMonthlyDeposit=maxMonthlyDeposit;
        this.maxAllowedWithdrawals=maxAllowedwithDrawals;
        this.transactions=new ArrayList<>();
        this.openingDate=LocalDate.now();
        this.withdrawalCount=0;
        this.balance=0.0;
    }
    public double getBalance(){
        return balance;
    }
    public LocalDate getOpeningDate(){
        return openingDate;
    }
    public List<BankTransaction>getTransactions(){
        return transactions;
    }
    public boolean canAcceptDeposit(double amount) {

        if (amount <= 0) {
            return false;
        }

        double monthlyTotal = 0.0;
        LocalDateTime now = LocalDateTime.now();

        for (BankTransaction t : transactions) {
            if (t.getAmount() > 0 &&
                    t.getDateTime().getMonth() == now.getMonth() &&
                    t.getDateTime().getYear() == now.getYear()) {

                monthlyTotal += t.getAmount();
            }
        }

        return (monthlyTotal + amount) <= maxMonthlyDeposit;
    }


    public boolean deposit(double amount, String reference) {

        if (!canAcceptDeposit(amount)) {
            return false;
        }

        balance += amount;

        BankTransaction transaction =
                new BankTransaction(amount, reference);

        transactions.add(transaction);

        return true;
    }

    public boolean withdraw(double amount, String reference) {

        if (amount <= 0) {
            return false;
        }

        if (balance >= amount) {

            balance -= amount;
            withdrawalCount++;

            BankTransaction transaction =
                    new BankTransaction(-amount, reference);

            transactions.add(transaction);

            return true;
        }

        return false;
    }


    public double getInterestRate() {

        if (withdrawalCount > maxAllowedWithdrawals) {
            return reducedInterestRate;
        }

        return normalInterestRate;
    }





}