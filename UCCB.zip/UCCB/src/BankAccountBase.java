import java.util.ArrayList;
import java.util.List;
public abstract class BankAccountBase {
    protected double balance;
    protected List<BankTransaction> transactions;

    public BankAccountBase() {
        this.balance = 0.0;
        this.transactions = new ArrayList<>();
    }

    public double getBalance() {
        return balance;
    }

    public List<BankTransaction> getTransactions() {
        return transactions;
    }

    public boolean deposit(double amount, String reference) {
        if (amount <= 0) {
            return false;
        }

        balance += amount;
        transactions.add(new BankTransaction(amount, reference));
        return true;
    }

    public boolean withdraw(double amount, String reference) {
        if (amount <= 0) {
            return false;
        }

        if (balance >= amount) {
            balance -= amount;
            transactions.add(new BankTransaction(-amount, reference));
            return true;
        }

        return false;
    }
}
