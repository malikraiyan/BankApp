import java.util.ArrayList;
import java.util.List;

public class BankAccount {

    private double balance;
    private List<BankTransaction> transactions;

    public BankAccount() {
        this.balance = 0.0;
        this.transactions = new ArrayList<>();
    }

    public double getBalance() {
        return balance;
    }

    public List<BankTransaction> getTransactions() {
        return transactions;
    }


    public void deposit(double amount, String reference) {
        if (amount <= 0) {
            return;
        }

        balance += amount;

        BankTransaction transaction =
                new BankTransaction(amount, reference);

        transactions.add(transaction);
    }


    public boolean withdraw(double amount, String reference) {
        if (amount <= 0) {
            return false;
        }

        if (balance >= amount) {
            balance -= amount;

            BankTransaction transaction =
                    new BankTransaction(-amount, reference);

            transactions.add(transaction);

            return true;
        }

        return false;
    }


    public boolean canMakePayment(double amount) {
        return balance >= amount;
    }
}