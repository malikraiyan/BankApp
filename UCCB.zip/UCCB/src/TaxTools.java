import java.time.LocalDateTime;

public class TaxTools {
    static boolean validNINumber(String NINOs){
        if(NINOs==null){
            return false;
        }
        if (NINOs.length()!=9) {
            return false;
        }
        char first=NINOs.charAt(0);
        char second=NINOs.charAt(1);
        if(!(first>='A' && first<='Z')){
            return false;
        }
        if(!(second>='A' && second<='Z')){
            return false;
        }
        if(first=='D' || first=='F' || first=='I' || first=='Q' || first=='U' || first=='V'|| first=='O'){
            return false;
        }
        if(second=='D' || second=='F' || second=='I' || second=='Q' || second=='U' || second=='V' || second=='O'){
            return false;
        }
        String prefix = "" + first + second;
        if (prefix.equals("BG") || prefix.equals("GB") || prefix.equals("NK") || prefix.equals("KN") || prefix.equals("TN") || prefix.equals("NT") || prefix.equals("ZZ")){
            return false;
        }
        for(int i=2; i<=7; i++) {
            char c = NINOs.charAt(i);
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        char last = NINOs.charAt(8);
        if (!(last == 'A' || last == 'B' || last == 'C' || last == 'D')) {
            return false;
        }
        return true;
        }
     static LocalDateTime startOfTaxYearForDate(LocalDateTime dateTime){
        if (dateTime==null){
            return null;
        }
        int year =dateTime.getYear();
        LocalDateTime startThisYear=LocalDateTime.of(year,4,6,0,0);
        if(dateTime.isBefore(startThisYear)){
            return LocalDateTime.of(year - 1,4,6,0,0);
        }
        return startThisYear;
     }


}
