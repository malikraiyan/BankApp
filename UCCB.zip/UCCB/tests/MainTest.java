import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;
class MainTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void main() {

        Random random = new Random();
        String[] inputTokens = new String[300];

        for (int i = 0; i < 300; i++) {
            if (Math.random()>0.5){
              inputTokens[i]=(char)('a' + random.nextInt(26))+"";
            } else {
                inputTokens[i]= "" + (random.nextInt(20)-10);
            }
        }

        final ByteArrayInputStream stream = streamFromStrings(inputTokens);
        System.setIn(stream);

        assertDoesNotThrow(() -> Main.main(new String[0]), "If possible, ensure you handle possible invalid input from the user");

    }



    private static ByteArrayInputStream streamFromStrings(String[] strings) {
        final StringBuilder sb = new StringBuilder();
        for (String string : strings) {
            sb.append(string);
            sb.append(System.lineSeparator());
        }
        return new ByteArrayInputStream(sb.toString().getBytes());
    }
}