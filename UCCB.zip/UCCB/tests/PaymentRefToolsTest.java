import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import uk.ac.chester.testing.MethodsTester;
import uk.ac.chester.testing.handlers.MethodTestEventHandlerEN;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class PaymentRefToolsTest {

    private final MethodsTester<PaymentRefTools> tester = new MethodsTester<>(PaymentRefTools.class, new MethodTestEventHandlerEN());

    @Nested
    class Task1 {

        @Test
        void isHyphen() {
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,'-'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'.'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'–'), "– is an 'En dash', not a hyphen");
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,' '));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'a'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,','));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'='));
        }

        @Test
        void isFullStop() {
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,'.'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'/'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'-'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,' '));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'a'));
        }

        @Test
        void isSpace() {
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,' '));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,(char)31), "Only the space that you get when you press the space bar is allowed");
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'!'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'_'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'a'));
        }

        @Test
        void isValidSymbolForPaymentReference() {
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,' '));
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,'.'));
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,'-'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'a'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'!'));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,'_'));
        }

        @Test
        void isLowerLatinAlphabet() {
            for (char character = 0; character < 97; character++) {
                assertFalse(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
            }
            for (char character = 123; character <= 255; character++) {
                assertFalse(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
            }
            for (char character = 'a'; character <= 'z'; character++){
                assertTrue(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");

            }
        }

        @Test
        void isUpperLatinAlphabet() {
            for (char character = 0; character < 65; character++) {
                assertFalse(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
            }
            for (char character = 91; character <= 255; character++) {
                assertFalse(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
            }
            for (char character = 'A'; character <= 'Z'; character++){
                assertTrue(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");

            }
        }

        @Test
        void isLatinAlphabet() {

            for (char character = 0; character <= 255; character++) {
                if (character >= 65 && character <= 90 || character >= 97 && character <= 122){
                    assertTrue(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
                } else {
                    assertFalse(tester.executeStaticMatchingCaller(boolean.class,character), character + " is not a lowercase latin letter");
                }
            }

        }

        @Test
        void isValidCharacterForPaymentReference() {

            List<Character> validLetters = new ArrayList<>();
            for (char character = 'a'; character <= 'z'; character++) {
                validLetters.add(character);
            }
            for (char character = 'A'; character <= 'Z'; character++) {
                validLetters.add(character);
            }
            for (char character = '0'; character <= '9'; character++) {
                validLetters.add(character);
            }
            validLetters.add('-');
            validLetters.add('.');
            validLetters.add(' ');

            for (char character = 0; character <= 255; character++) {
                if (validLetters.contains(character)) {
                    assertTrue(tester.executeStaticMatchingCaller(boolean.class, character), character + "is a valud character");
                } else {
                    assertFalse(tester.executeStaticMatchingCaller(boolean.class, character), character + "is not a valid character");
                }

            }

        }


        @Test
        void exceedsMaximumPaymentRefLength() {
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,"x".repeat(39) ));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,"x".repeat(40) ));
            assertFalse(tester.executeStaticMatchingCaller(boolean.class,"yy"));
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,"x".repeat(41)));
            assertTrue(tester.executeStaticMatchingCaller(boolean.class,"x".repeat(129)));

        }

        @Test
        void truncate() {
            String[] originals = {"ab".repeat(20), "abc".repeat(9), "xy".repeat(1000), "a".repeat(41), "b".repeat(39)};
            String[] truncatedItems = {"ab".repeat(20), "abc".repeat(9), "xy".repeat(20), "a".repeat(40), "b".repeat(39)};

            for (int i = 0; i < originals.length; i++) {

                String original = originals[i];
                String truncated = truncatedItems[i];

                assertEquals(truncated,tester.executeStaticMatchingCaller(String.class, original, 40));
            }

        }
    }

    @Nested
    class Task2{

        @Test
        void countLongPaymentRefs() {

            String[] originals = {"ab".repeat(20), "abc".repeat(9), "xy".repeat(1000), "a".repeat(41), "b".repeat(39)};
            assertEquals(2, tester.executeStaticMatchingCaller(int.class, (Object) originals));

            String[] moreStrings = {"ac ahs a", "gh", "nxt".repeat(45), "a", "7s52".repeat(28), "abcdef".repeat(900)};
            assertEquals(3, tester.executeStaticMatchingCaller(int.class, (Object) moreStrings));

        }

        @Test
        void filterLongPaymentRefs() {

            ArrayList<String> refs = new ArrayList<>();
            ArrayList<String> shortRefs = new ArrayList<>();

            for (int i = 1; i < 70; i++) {
                int offset = new Random().nextInt(26);
                char letter = (char) ('a' + offset);
                String ref = (letter + "").repeat(i);
                refs.add(ref);
                if (i <= 40) {
                    shortRefs.add(ref);
                }
            }
            Collections.shuffle(refs);
            tester.executeStaticMatchingCaller(void.class, refs);
            Collections.sort(refs);
            Collections.sort(shortRefs);
            assertEquals(shortRefs, refs);

        }
    }
}