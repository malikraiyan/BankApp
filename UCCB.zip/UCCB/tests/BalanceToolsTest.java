import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import uk.ac.chester.testing.MethodsTester;
import uk.ac.chester.testing.handlers.MethodTestEventHandlerEN;

import static org.junit.jupiter.api.Assertions.*;

class BalanceToolsTest {

    private final MethodsTester<BalanceTools> tester = new MethodsTester<>(BalanceTools.class, new MethodTestEventHandlerEN());

    @Nested
    class Task1 {

        @Test
        void newBalance() {

            int[][] args = {
                    {0, 0, 0},
                    {1, 1, 2},
                    {40000, 20000, 60000},
                    {0, -4000, -4000}};

            for (int[] argSet : args) {
                int startingBalance = argSet[0];
                int deposit = argSet[1];
                int newBalance = argSet[2];

                assertEquals(newBalance, tester.executeStaticMatchingCaller(int.class, startingBalance, deposit),
                        "A balance of " + startingBalance + " with a deposit of " + deposit + " should end up as " + newBalance);
            }
        }


        @Test
        void hasAvailableFunds() {
            assertTrue(tester.executeStaticMatchingCaller(boolean.class, 1, 0), String.format("If the balance (%d), is higher than the transaction value (%d), then the account has funds", 1, 0));
            assertTrue(tester.executeStaticMatchingCaller(boolean.class, 60, 60), "If the balance is the same as the transaction value, then the account has funds");
            assertFalse(tester.executeStaticMatchingCaller(boolean.class, 98, 99), "If the balance is lower than the transaction value, then the account does not have funds");
            assertFalse(tester.executeStaticMatchingCaller(boolean.class, -50, 1), "If the balance is negative, the account does not have funds");
        }

        @Test
        void annualBondInterest() {
            assertEquals(1, tester.executeStaticMatchingCaller(int.class, 2, 0.5), "A balance of 2 with 50% interest will have generated interest of 1 after a year");
            assertEquals(0, tester.executeStaticMatchingCaller(int.class, 5, 0.0), "A balance of 5 with 0% interest will generate no interest");
            assertEquals(0, tester.executeStaticMatchingCaller(int.class, 10, 0.05), "A balance of 10p with 5% interest will not generate even 1p's worth of interest (as interest is rounded down)");

        }

        @Test
        void bondIllustration() {
            assertEquals(3, tester.executeStaticMatchingCaller(int.class, 2, 0.5), "A balance of 2 with 50% interest will have increased to 3 after a year");
            assertEquals(5, tester.executeStaticMatchingCaller(int.class, 5, 0.0), "A balance of 5 with 0% interest will not increase");
            assertEquals(10, tester.executeStaticMatchingCaller(int.class, 10, 0.05), "A balance of 10p with 5% interest will not increase as interest is rounded down");
            assertEquals(21, tester.executeStaticMatchingCaller(int.class, 20, 0.05), "A balance of 20 with 5% interest will have increased to 21 after a year");
        }
    }

    @Nested
    class Task2 {

        @Test
        void bondIllustrationMultiYear() {

            int[] starts = {100, 100, 200};
            double[] rates = {0, 0.2, 0.15};
            int[] years = {2, 4, 7};
            int[] results = {100, 206, 529};

            for (int i = 0; i < 2; i++) {
                String message = String.format("%d invested at %.2f%% for %d years would be worth %d", starts[i], rates[i], years[i], results[i]);
                assertEquals(results[i], tester.executeStatic(int.class, "bondIllustration", starts[i], rates[i], years[i]), message);
            }

        }
    }

}