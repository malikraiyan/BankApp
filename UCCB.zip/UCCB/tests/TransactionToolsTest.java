import org.junit.jupiter.api.Test;
import uk.ac.chester.testing.MethodsTester;
import uk.ac.chester.testing.handlers.MethodTestEventHandlerEN;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TransactionToolsTest {

    private final MethodsTester<TransactionTools> tester = new MethodsTester<>(TransactionTools.class, new MethodTestEventHandlerEN());

    private final Transaction t1 = new Transaction(2,PaymentReference.of("T1"), Transaction.Type.CREDIT_CARD, LocalDateTime.of(2025,9,1,0,0));
    private final Transaction t1Duplicate = new Transaction(2,PaymentReference.of("T1"), Transaction.Type.CREDIT_CARD);
    private final Transaction t1DifAmount = new Transaction(3,PaymentReference.of("T1"), Transaction.Type.CREDIT_CARD, LocalDateTime.of(2025,9,1,0,0));
    private final Transaction t1DifRef = new Transaction(2,PaymentReference.of("Wrong ref"), Transaction.Type.CREDIT_CARD, LocalDateTime.of(2025,9,1,0,0));
    private final Transaction t1DifType = new Transaction(2,PaymentReference.of("T1"), Transaction.Type.INTEREST, LocalDateTime.of(2025,9,1,0,0));



    @Test
    void isDuplicate(){
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, t1, t1Duplicate));
        assertFalse(tester.executeStaticMatchingCaller(boolean.class,t1,t1DifAmount));
        assertFalse(tester.executeStaticMatchingCaller(boolean.class,t1,t1DifRef));
        assertFalse(tester.executeStaticMatchingCaller(boolean.class,t1,t1DifType));
    }


    @Test
    void containsDuplicate() {

        List<Transaction> transactions = new ArrayList<>();

        transactions.add(t1);
        transactions.add(t1DifType);
        transactions.add(t1DifRef);
        transactions.add(t1DifAmount);

        Collections.shuffle(transactions);
        assertFalse(tester.executeStaticMatchingCaller(boolean.class, (Object)transactions.toArray(new Transaction[0])));

        Collections.shuffle(transactions);
        assertFalse(tester.executeStaticMatchingCaller(boolean.class, (Object)transactions.toArray(new Transaction[0])));

        transactions.add(t1Duplicate);
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, (Object)transactions.toArray(new Transaction[0])));

        Collections.shuffle(transactions);
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, (Object)transactions.toArray(new Transaction[0])));

    }

    @Test
    void countMatchingTransactions() {

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(t1DifType);
        transactions.add(t1DifRef);
        transactions.add(t1DifAmount);

        assertEquals(0, tester.executeStaticMatchingCaller(int.class, t1,transactions));
        transactions.add(t1Duplicate);
        assertEquals(1, tester.executeStaticMatchingCaller(int.class, t1,transactions));
        transactions.add(t1Duplicate);
        transactions.add(t1);
        Collections.shuffle(transactions);
        assertEquals(3, tester.executeStaticMatchingCaller(int.class, t1,transactions));

        transactions.add(t1DifRef);
        assertEquals(2, tester.executeStaticMatchingCaller(int.class, t1DifRef,transactions));

    }

    @Test
    void removeDuplicates() {

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(t1DifType);
        transactions.add(t1DifRef);
        transactions.add(t1DifAmount);

        List<Transaction> copyOfOriginal = new ArrayList<>(transactions);

        tester.executeStaticMatchingCaller(void.class, transactions);

        assertEquals(transactions.size(), copyOfOriginal.size(), "list has had item removed (or added) when there were no duiplicates");

        for (int i = 0; i < transactions.size(); i++) {
            assertEquals(transactions.get(i), copyOfOriginal.get(i));
        }

        transactions.addFirst(t1DifRef);
        tester.executeStaticMatchingCaller(void.class, transactions);

        for (int i = 0; i < transactions.size(); i++) {
            assertEquals(transactions.get(i), copyOfOriginal.get(i));
        }

        transactions.add(3,t1DifAmount);
        tester.executeStaticMatchingCaller(void.class, transactions);
        for (int i = 0; i < transactions.size(); i++) {
            assertEquals(transactions.get(i), copyOfOriginal.get(i));
        }

    }
}