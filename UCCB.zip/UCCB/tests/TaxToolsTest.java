import org.junit.jupiter.api.Test;
import uk.ac.chester.testing.MethodsTester;
import uk.ac.chester.testing.handlers.MethodTestEventHandlerEN;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TaxToolsTest {


    private final MethodsTester<TaxTools> tester = new MethodsTester<>(TaxTools.class, new MethodTestEventHandlerEN());



    @Test
    void validNINumber() {

        //valid numbers
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, "PR987654A"), "Valid NI Number");
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, "AB123456D"), "Valid NI Number");
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, "AB123456C"), "Valid NI number should return true");
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, "JK987654D"), "Valid NI number should return true");
        assertTrue(tester.executeStaticMatchingCaller(boolean.class, "MN112233B"), "Valid NI number should return true");

        //clearly invalid numbers
        assertFalse(tester.executeStaticMatchingCaller(boolean.class,"123456789"), "All digits, no letters");
        assertFalse(tester.executeStaticMatchingCaller(boolean.class,""), "Empty string");

    }
    @Test
    void validNINumberLength() {

        //wrong length
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","AB123456D5"), "NI number too long");
        assertFalse(tester.executeStatic(boolean.class,"validNINumber", "AB123456DD"), "NI number too long");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber","AB123456"),"NI number too short - missing suffix");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber","AB12345C"), "Only five digits - missing number");
        assertFalse(tester.executeStatic(boolean.class,"validNINumber", "A123456C"),"Missing second prefix letter");

        //duplicate valid check to avoid false positives
        assertTrue(tester.executeStatic(boolean.class, "validNINumber","PR987654A"), "Valid NI Number");

    }
    @Test
    void validNINumberInitialLetters() {
        //invalid initial letters
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","ÁB123456D"), "Á (with an accent) is not a valid start letter");
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","AÁ123456D"), "Á (with an accent) is not a valid second letter");


        //duplicate valid check to avoid false positives
        assertTrue(tester.executeStatic(boolean.class,"validNINumber", "PR987654A"), "Valid NI Number");
    }
    @Test
    void validNINumberFirstTwoCharacters() {
        //numbers in first two characters
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","A1123456C"), "Number in second place");
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","1A123456C"), "Number in first place");

        //duplicate valid check to avoid false positives
        assertTrue(tester.executeStatic(boolean.class, "validNINumber","PR987654A"), "Valid NI Number");
    }
    @Test
    void validNINumberEndCharacter() {
        //end character not A-D
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","AB123456E"), "Invalid suffix letter (should be A-D)");
        //duplicate valid check to avoid false positives
        assertTrue(tester.executeStatic(boolean.class,"validNINumber", "PR987654A"), "Valid NI Number");


    }
    @Test
    void validNINumberMiddleChars() {
        //non-numeric middle characters
        assertFalse(tester.executeStatic(boolean.class,"validNINumber","AB12C456D"), "Letter in number position");
//duplicate valid check to avoid false positives
        assertTrue(tester.executeStatic(boolean.class, "validNINumber","PR987654A"), "Valid NI Number");



    }


    @Test
    void validNiNumberAdvanced() {
        assertFalse(tester.executeStatic(boolean.class, "validNINumber", "AQ123456A"), "Invalid letter used - Q not allowed");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber", "DF123456A"), "Invalid letter used - neither D or F are allowed");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber", "GB123456B"), "Invalid prefix combination");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber", "NT123456C"), "Invalid prefix combination");
        assertFalse(tester.executeStatic(boolean.class, "validNINumber", "AO123456C"), "Can't have O in second place");

    }



    @Test
    void startOfTaxYearForDate() {

        LocalDateTime start26TaxYear = LocalDateTime.of(2026,4,6, 0, 0 );
        assertEquals(start26TaxYear, tester.executeStaticMatchingCaller(LocalDateTime.class, LocalDateTime.of(2027,4,5, 12,45)));

        LocalDateTime start27TaxYear = LocalDateTime.of(2027,4,6, 0, 0 );
        assertEquals(start27TaxYear, tester.executeStaticMatchingCaller(LocalDateTime.class, LocalDateTime.of(2027,4,6, 0,1)));
        assertEquals(start27TaxYear, tester.executeStaticMatchingCaller(LocalDateTime.class, LocalDateTime.of(2027,11,29, 2,52)));
        assertEquals(start27TaxYear, tester.executeStaticMatchingCaller(LocalDateTime.class, LocalDateTime.of(2028,4,5, 23,59)));

    }


}