import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import uk.ac.chester.testing.*;
import uk.ac.chester.testing.handlers.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WalletTest {

    private final FieldsTester<Wallet> fieldsTester = new FieldsTester<>(Wallet.class, new FieldsTestEventHandlerEN());
    private final ConstructorsTester<Wallet> constructorsTester = new ConstructorsTester<>(Wallet.class, new ConstructorsTestEventHandlerEN());
    private final MethodsTester<Wallet> methodsTester = new MethodsTester<>(Wallet.class, new MethodTestEventHandlerEN());

    @BeforeAll
    static void generalTest(){
        ClassTester<Wallet> classTester = new ClassTester<>(Wallet.class, new ClassTestEventHandlerEN());
        classTester.checkFieldNames();
        classTester.checkFields();
        classTester.checkMethods();
    }

    @Test
    void startBalanceField(){
        fieldsTester.test(AccessModifier.PRIVATE, Collections.singleton(NonAccessModifier.FINAL), int.class, "startingBalance", true);
    }

    @Test
    void constructor(){
        constructorsTester.test(AccessModifier.PUBLIC, 500);
    }

    @Test
    void balanceOpeningValue() {

        for (int openingBalance = 0; openingBalance < 20000; openingBalance+=400) {
            InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),openingBalance);
            int actualOpeningBalance = instanceTester.getFieldValue(int.class, "startingBalance");
            assertEquals(openingBalance,actualOpeningBalance,"openingBalance should match value passed to constructor");
        }
    }

    @Test
    void transactions(){
        fieldsTester.test(AccessModifier.PRIVATE, List.class, "transactions", true );
    }

    @Test
    void depositMethodExists() {
        methodsTester.testExistence(true,AccessModifier.PUBLIC,false,void.class,"deposit",int.class);
    }

    @Test
    void depositMethodRuns() {
        InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),0);
        final int depositAmount = 40;
        instanceTester.executeMethod(void.class,"deposit",depositAmount);
        List<?> list = instanceTester.getFieldValue(List.class, "transactions");
        List<Integer> typedList = integerListFromGeneric(list);
        assertEquals(depositAmount, typedList.getLast(), "Deposit method doesn't appear to be adding values to the list of transactions");
    }

    @Test
    void currentBalanceBeforeTransactions() {
        InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),0);
        assertEquals(0,instanceTester.executeMethod(int.class,"currentBalance"));
    }

    @Test
    void currentBalanceAfterDeposit(){
        InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),40);
        final int depositAmount = 40;
        instanceTester.executeMethod(void.class,"deposit",depositAmount);
        assertEquals(80,instanceTester.executeMethod(int.class,"currentBalance"), "With a starting balance of 40 and a deposit of 40, the current balance should be 80");

    }

    @Test
    void withdrawMethodExists(){
        methodsTester.testExistence(true,AccessModifier.PUBLIC,false,boolean.class,"withdraw",int.class);
    }

    @Test
    void withdrawMethodAmendsTransactions() {
        InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),100);
        final int withdrawalAmount = 60;
        instanceTester.executeMethod(boolean.class,"withdraw",withdrawalAmount);
        List<?> list = instanceTester.getFieldValue(List.class, "transactions");
        List<Integer> typedList = integerListFromGeneric(list);
        assertEquals(-withdrawalAmount, typedList.getLast(), "Withdrawal method doesn't appear to be adding values to the list of transactions");
    }

    private static List<Integer> integerListFromGeneric(List<?> list) {
        List<Integer> typedList = new ArrayList<>();
        for (Object item : list){
            if (item instanceof Integer){
                typedList.add((Integer)item);
            } else {
                fail("Transaction list appears to contain something other than integers");
            }
        }
        return typedList;
    }

    @Test
    void withdrawMethodRuns(){
        InstanceTester<Wallet> instanceTester = new InstanceTester<>(Wallet.class, new InstanceTestEventHandlerEN(),50);
        final int withdrawalAmount = 40;
        assertTrue(instanceTester.executeMethod(boolean.class,"withdraw",withdrawalAmount),"With a starting balance of 50 and a withdrawal of 40, the withdrawal should be allowed");
        assertEquals(10,instanceTester.executeMethod(int.class,"currentBalance"), "With a starting balance of 50 and a withdrawal of 40, the new balance should be 10");
        assertTrue(instanceTester.executeMethod(boolean.class,"withdraw",10),"With a starting balance of 10 and a withdrawal of 10, the withdrawal should be allowed");
        assertEquals(0,instanceTester.executeMethod(int.class,"currentBalance"), "With a starting balance of 10 and a withdrawal of 10, the new balance should be 0");
        assertFalse(instanceTester.executeMethod(boolean.class,"withdraw",10), "With a starting balance of 0 and a withdrawal of 10, the withdrawal should not be allowed");
        assertEquals(0,instanceTester.executeMethod(int.class,"currentBalance"), "With a starting balance of 0 and a failed withdrawal of 10, the balance should be still be 0");

    }

}